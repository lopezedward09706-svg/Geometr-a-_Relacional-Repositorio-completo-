
import { NodeValueType, QNode, QConnection, SimulationState } from '../types';

export const generateSimulation = (numNodes: number, type: NodeValueType): SimulationState => {
  const nodes: QNode[] = [];
  const connections: QConnection[] = [];
  const radius = 8.5; // Threshold for relational connection

  // 1. Generate Nodes
  for (let i = 0; i < numNodes; i++) {
    let A, B, C;

    if (type === 'Spin') {
      A = Math.floor(Math.random() * 3) - 1; // -1, 0, 1
      B = Math.floor(Math.random() * 3) - 1;
      C = Math.floor(Math.random() * 3) - 1;
    } else if (type === 'Binary') {
      A = Math.random() > 0.5 ? 1 : 0;
      B = Math.random() > 0.5 ? 1 : 0;
      C = Math.random() > 0.5 ? 1 : 0;
    } else {
      A = parseFloat(Math.random().toFixed(2));
      B = parseFloat(Math.random().toFixed(2));
      C = parseFloat(Math.random().toFixed(2));
    }

    const sum = parseFloat((A + B + C).toFixed(2));
    const isStable = Math.abs(sum) < 0.01;

    nodes.push({
      id: i,
      A, B, C,
      x: (Math.random() - 0.5) * 25,
      y: (Math.random() - 0.5) * 25,
      z: (Math.random() - 0.5) * 25,
      sum,
      isStable
    });
  }

  // 2. Establish Relational Connections
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const n1 = nodes[i];
      const n2 = nodes[j];
      const dist = Math.sqrt(
        Math.pow(n1.x - n2.x, 2) + 
        Math.pow(n1.y - n2.y, 2) + 
        Math.pow(n1.z - n2.z, 2)
      );

      if (dist < radius) {
        connections.push({
          from: n1.id,
          to: n2.id,
          strength: 1 - (dist / radius)
        });
      }
    }
  }

  return {
    nodes,
    connections,
    type,
    timestamp: new Date().toISOString()
  };
};
