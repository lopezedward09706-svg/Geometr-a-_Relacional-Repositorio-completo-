
export type NodeValueType = 'Spin' | 'Binary' | 'Continuous';

export interface QNode {
  id: number;
  A: number;
  B: number;
  C: number;
  x: number;
  y: number;
  z: number;
  isStable: boolean;
  sum: number;
}

export interface QConnection {
  from: number;
  to: number;
  strength: number;
}

export interface SimulationState {
  nodes: QNode[];
  connections: QConnection[];
  timestamp: string;
  type: NodeValueType;
}

export interface AnalysisResult {
  summary: string;
  recommendations: string;
}
