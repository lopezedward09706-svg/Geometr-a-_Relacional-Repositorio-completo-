
import React, { useEffect, useState } from 'react';
import { NodeValueType } from '../types';
import { Settings, Play, Database, Download, FileText, Cpu, Key, CheckCircle2, Globe } from 'lucide-react';

interface SidebarProps {
  numNodes: number;
  setNumNodes: (n: number) => void;
  valueType: NodeValueType;
  setValueType: (t: NodeValueType) => void;
  onRun: () => void;
  isSimulating: boolean;
  onExportJson: () => void;
  onDownloadReport: () => void;
  hasSimulation: boolean;
}

// Augment the Window interface to include aistudio properties, using an optional modifier to avoid declaration conflicts.
declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

export const Sidebar: React.FC<SidebarProps> = ({
  numNodes, setNumNodes, valueType, setValueType, onRun, isSimulating,
  onExportJson, onDownloadReport, hasSimulation
}) => {
  const [hasCustomKey, setHasCustomKey] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio && window.aistudio.hasSelectedApiKey) {
        const hasKey = await window.aistudio.hasSelectedApiKey();
        setHasCustomKey(hasKey);
      }
    };
    checkKey();
    const interval = setInterval(checkKey, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleOpenKeyPicker = async () => {
    if (window.aistudio && window.aistudio.openSelectKey) {
      await window.aistudio.openSelectKey();
      // Assume success as per guidelines to avoid race conditions
      setHasCustomKey(true);
    }
  };

  return (
    <aside className="w-80 bg-slate-900/30 border-r border-slate-800 flex flex-col z-10 shrink-0">
      <div className="p-6 flex flex-col gap-8 overflow-y-auto flex-1 scrollbar-none">
        
        {/* Settings Group */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-slate-400">
            <Settings className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-widest">Protocolos de Red</span>
          </div>
          
          <div className="space-y-4">
            <label className="block">
              <span className="text-xs text-slate-400 font-bold uppercase tracking-tighter mb-2 block">Densidad de Nodos ({numNodes})</span>
              <input 
                type="range" 
                min="5" 
                max="120" 
                value={numNodes} 
                onChange={(e) => setNumNodes(parseInt(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-[9px] text-slate-600 mt-1 font-mono">
                <span>5</span>
                <span>120</span>
              </div>
            </label>

            <label className="block">
              <span className="text-xs text-slate-400 font-bold uppercase tracking-tighter mb-2 block">Geometría de Valor</span>
              <select 
                value={valueType}
                onChange={(e) => setValueType(e.target.value as NodeValueType)}
                className="w-full bg-slate-800/80 border border-slate-700 text-slate-200 text-sm rounded-lg focus:ring-1 focus:ring-blue-500 block p-2.5 outline-none transition-all"
              >
                <option value="Spin">Métrica de Spin (+1, 0, -1)</option>
                <option value="Binary">Red Binaria (0, 1)</option>
                <option value="Continuous">Espectro Continuo (0.0 - 1.0)</option>
              </select>
            </label>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={onRun}
          disabled={isSimulating}
          className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-xl text-xs tracking-widest
            ${isSimulating 
              ? 'bg-slate-800 cursor-not-allowed text-slate-500' 
              : 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-500/20 active:scale-[0.98]'}`}
        >
          {isSimulating ? (
            <>
              <Cpu className="w-5 h-5 animate-spin" />
              COLAPSANDO FUNCIÓN...
            </>
          ) : (
            <>
              <Play className="w-5 h-5 fill-current" />
              EJECUTAR SIMULACIÓN
            </>
          )}
        </button>

        <div className="h-px bg-slate-800/50" />

        {/* API Key Status */}
        <div className="space-y-3">
          <div className="flex items-center justify-between text-slate-500">
            <div className="flex items-center gap-2">
              <Key className="w-3 h-3" />
              <span className="text-[10px] font-bold uppercase tracking-widest">Enlace Neural (IA)</span>
            </div>
            {hasCustomKey && (
              <div className="flex items-center gap-1 text-emerald-500 text-[10px] font-bold">
                <CheckCircle2 className="w-3 h-3" />
                ESTABLE
              </div>
            )}
          </div>
          <button
            onClick={handleOpenKeyPicker}
            className={`w-full flex items-center gap-3 p-3 rounded-lg border border-dashed transition-all text-xs
              ${hasCustomKey 
                ? 'bg-emerald-950/10 border-emerald-900/40 text-emerald-400 hover:bg-emerald-950/20' 
                : 'bg-slate-800/40 border-slate-700 text-slate-400 hover:border-blue-500 hover:text-blue-400'}`}
          >
            <Key className="w-4 h-4 shrink-0" />
            <div className="text-left leading-tight">
              <div className="font-bold text-[11px] uppercase tracking-wider">{hasCustomKey ? 'Clave Activa' : 'Vincular Clave'}</div>
              <div className="text-[9px] opacity-60 font-normal">Para análisis de alta fidelidad</div>
            </div>
          </button>
          <a 
            href="https://ai.google.dev/gemini-api/docs/billing" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="block text-[9px] text-blue-500 hover:underline text-center"
          >
            Configuración de facturación y cuotas
          </a>
        </div>

        {/* Theory Reference */}
        <div className="space-y-3 p-4 bg-blue-950/10 border border-blue-900/20 rounded-xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-1 opacity-10">
             <Globe className="w-12 h-12 text-blue-400" />
          </div>
          <h4 className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">Base Teórica</h4>
          <p className="text-[11px] text-slate-400 leading-relaxed italic relative z-10">
            "La estabilidad nodal se alcanza cuando la suma escalar de las componentes es nula, eliminando la torsión residual."
          </p>
        </div>
      </div>

      {/* Footer Area */}
      <div className="p-6 border-t border-slate-800 space-y-3 bg-slate-900/20">
        <button 
          onClick={onDownloadReport}
          disabled={!hasSimulation}
          className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-slate-800 text-slate-400 transition-colors group disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <FileText className="w-4 h-4 group-hover:text-white" />
          <span className="text-xs font-medium group-hover:text-white uppercase tracking-tighter">Descargar Reporte</span>
        </button>
        <button 
          onClick={onExportJson}
          disabled={!hasSimulation}
          className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-slate-800 text-slate-400 transition-colors group disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <Database className="w-4 h-4 group-hover:text-white" />
          <span className="text-xs font-medium group-hover:text-white uppercase tracking-tighter">Exportar Datos RAW</span>
        </button>
      </div>
    </aside>
  );
};
