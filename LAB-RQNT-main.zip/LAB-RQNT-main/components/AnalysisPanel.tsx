
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { SimulationState } from '../types';
import { Sparkles, BrainCircuit, Terminal, Loader2, AlertTriangle, Key, Activity } from 'lucide-react';

interface AnalysisPanelProps {
  simulation: SimulationState;
}

export const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ simulation }) => {
  const [analysis, setAnalysis] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [error, setError] = useState<{message: string, isQuota: boolean} | null>(null);

  const handleOpenKeyPicker = async () => {
    try {
      if (window.aistudio && window.aistudio.openSelectKey) {
        await window.aistudio.openSelectKey();
        analyzeSimulation();
      }
    } catch (e) {
      console.error("Error opening key picker", e);
    }
  };

  const analyzeSimulation = async () => {
    setIsAnalyzing(true);
    setError(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const model = 'gemini-3-pro-preview';

      const prompt = `
        Como experto en física cuántica y teoría de redes relacionales (R-QNT), analiza los siguientes datos de simulación.
        
        SISTEMA:
        - Tipo: ${simulation.type}
        - Total Nodos: ${simulation.nodes.length}
        - Total Conexiones (Relaciones): ${simulation.connections.length}
        - Nodos Coherentes (Estables): ${simulation.nodes.filter(n => n.isStable).length}
        - Nodos en Tensión (Inestables): ${simulation.nodes.filter(n => !n.isStable).length}
        
        MUESTRA DE TOPOLOGÍA (Primeros 10 nodos):
        ${JSON.stringify(simulation.nodes.slice(0, 10).map(n => ({ id: n.id, components: [n.A, n.B, n.C], stable: n.isStable })))}
        
        TAREA ANALÍTICA:
        1. Evalúa la densidad relacional y su impacto en la estabilidad global.
        2. Según la teoría de torsión Cartan aplicada a redes, ¿existe un patrón de colapso inminente o es una estructura auto-sostenida?
        3. Proporciona una recomendación para el Investigador Edward Pérez López sobre cómo ajustar los parámetros de entrada.
        
        Escribe una respuesta técnica, elegante y inspiradora.
      `;

      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
          temperature: 0.85,
          topP: 0.95,
        }
      });

      setAnalysis(response.text || 'Sin respuesta del sistema central.');
    } catch (err: any) {
      console.error("API Error:", err);
      const msg = err.message || '';
      const isQuota = msg.includes('429') || msg.toLowerCase().includes('quota') || msg.toLowerCase().includes('exhausted');
      const isNotFound = msg.includes('Requested entity was not found');

      if (isNotFound) {
        setError({ 
          message: 'Clave API no válida o proyecto no configurado correctamente. Por favor, selecciona una clave con facturación activa.', 
          isQuota: true 
        });
      } else if (isQuota) {
        setError({ 
          message: 'Límite de cuota alcanzado (429). Para investigaciones ilimitadas, usa una clave API propia.', 
          isQuota: true 
        });
      } else {
        setError({ 
          message: 'Error de sincronización con el núcleo de IA. Reintenta la operación.', 
          isQuota: false 
        });
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    if (simulation) {
      analyzeSimulation();
    }
  }, [simulation]);

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="p-4 border-b border-slate-800 bg-slate-900/40 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-4 h-4 text-purple-400" />
          <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-300">Inteligencia de Campo</h3>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={analyzeSimulation}
            disabled={isAnalyzing}
            className="p-1.5 hover:bg-slate-800 rounded transition-colors text-slate-400 hover:text-white"
          >
            {isAnalyzing ? <Loader2 className="w-4 h-4 animate-spin text-blue-400" /> : <Sparkles className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-5 scrollbar-thin scrollbar-thumb-slate-800">
        {isAnalyzing ? (
          <div className="space-y-4">
            <div className="h-3 bg-slate-800/40 rounded animate-pulse w-3/4" />
            <div className="h-3 bg-slate-800/40 rounded animate-pulse w-full" />
            <div className="h-3 bg-slate-800/40 rounded animate-pulse w-5/6" />
            <div className="h-3 bg-slate-800/40 rounded animate-pulse w-2/3" />
            <div className="h-3 bg-slate-800/40 rounded animate-pulse w-4/5" />
          </div>
        ) : error ? (
          <div className="p-5 bg-rose-950/20 border border-rose-900/30 rounded-xl flex flex-col gap-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0" />
              <div className="space-y-1">
                <span className="text-[10px] text-rose-400 font-bold uppercase tracking-widest">Alerta de Enlace</span>
                <p className="text-xs text-rose-200/80 leading-relaxed">{error.message}</p>
              </div>
            </div>
            {error.isQuota && (
              <button 
                onClick={handleOpenKeyPicker}
                className="w-full bg-rose-600 hover:bg-rose-500 text-white text-[10px] font-bold py-2 rounded-lg transition-all"
              >
                CONFIGURAR CLAVE PROPIA
              </button>
            )}
          </div>
        ) : analysis ? (
          <div className="prose prose-invert prose-xs max-w-none text-slate-300 font-serif leading-relaxed italic">
            <div className="whitespace-pre-wrap">{analysis}</div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-slate-700 gap-3 opacity-50">
            <Activity className="w-8 h-8" />
            <span className="text-[10px] uppercase tracking-widest">Sistema en Standby</span>
          </div>
        )}
      </div>

      <div className="p-3 bg-slate-900/20 border-t border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Terminal className="w-3 h-3 text-slate-500" />
          <span className="text-[9px] font-mono text-slate-600 uppercase tracking-widest">Núcleo Pro-3.1</span>
        </div>
        <div className="px-2 py-0.5 rounded-full bg-slate-800/50 border border-slate-700">
           <span className="text-[8px] font-mono text-slate-500 uppercase tracking-tighter">Status: Active</span>
        </div>
      </div>
    </div>
  );
};
