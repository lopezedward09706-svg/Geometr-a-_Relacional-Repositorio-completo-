
import React from 'react';
import { SimulationState } from '../types';

interface DataTableProps {
  simulation: SimulationState;
}

export const DataTable: React.FC<DataTableProps> = ({ simulation }) => {
  return (
    <div className="flex-1 overflow-auto scrollbar-thin scrollbar-thumb-slate-700">
      <table className="w-full text-left border-collapse">
        <thead className="sticky top-0 bg-slate-900 border-b border-slate-800 text-[10px] text-slate-500 uppercase tracking-widest font-mono">
          <tr>
            <th className="px-4 py-2 font-medium">ID</th>
            <th className="px-4 py-2 font-medium">A</th>
            <th className="px-4 py-2 font-medium">B</th>
            <th className="px-4 py-2 font-medium">C</th>
            <th className="px-4 py-2 font-medium">Estado</th>
          </tr>
        </thead>
        <tbody className="text-[11px] font-mono">
          {simulation.nodes.map((node) => (
            <tr key={node.id} className="border-b border-slate-800/50 hover:bg-slate-800/30 transition-colors">
              <td className="px-4 py-2 text-slate-400">#{node.id.toString().padStart(3, '0')}</td>
              <td className="px-4 py-2 text-slate-200">{node.A}</td>
              <td className="px-4 py-2 text-slate-200">{node.B}</td>
              <td className="px-4 py-2 text-slate-200">{node.C}</td>
              <td className="px-4 py-2">
                <span className={node.isStable ? 'text-emerald-500' : 'text-rose-500'}>
                  {node.isStable ? 'Estable' : 'Tensión'}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
