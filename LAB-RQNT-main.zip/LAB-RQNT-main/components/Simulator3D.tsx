
import React, { useEffect, useRef } from 'react';
import { SimulationState } from '../types';

interface Simulator3DProps {
  simulation: SimulationState;
}

declare const Plotly: any;

export const Simulator3D: React.FC<Simulator3DProps> = ({ simulation }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current || !simulation) return;

    // 1. Prepare Node Traces
    const xNodes = simulation.nodes.map(n => n.x);
    const yNodes = simulation.nodes.map(n => n.y);
    const zNodes = simulation.nodes.map(n => n.z);
    const colors = simulation.nodes.map(n => n.isStable ? '#10b981' : '#f43f5e');
    const sizes = simulation.nodes.map(n => n.isStable ? 10 : 7);
    const texts = simulation.nodes.map(n => `ID: ${n.id}<br>Estado: ${n.isStable ? 'COHERENTE' : 'TENSIÓN'}<br>Σ(A,B,C): ${n.sum}`);

    const nodeTrace = {
      x: xNodes,
      y: yNodes,
      z: zNodes,
      mode: 'markers',
      type: 'scatter3d',
      marker: {
        size: sizes,
        color: colors,
        opacity: 0.9,
        line: { color: 'white', width: 0.5 },
        symbol: 'circle'
      },
      text: texts,
      hoverinfo: 'text',
      name: 'Nodos'
    };

    // 2. Prepare Connection Traces (Edges)
    const xEdges: (number | null)[] = [];
    const yEdges: (number | null)[] = [];
    const zEdges: (number | null)[] = [];

    simulation.connections.forEach(conn => {
      const from = simulation.nodes[conn.from];
      const to = simulation.nodes[conn.to];
      if (from && to) {
        xEdges.push(from.x, to.x, null);
        yEdges.push(from.y, to.y, null);
        zEdges.push(from.z, to.z, null);
      }
    });

    const edgeTrace = {
      x: xEdges,
      y: yEdges,
      z: zEdges,
      mode: 'lines',
      type: 'scatter3d',
      line: {
        color: '#475569',
        width: 1,
        opacity: 0.2
      },
      hoverinfo: 'none',
      name: 'Relaciones'
    };

    const layout = {
      paper_bgcolor: 'rgba(0,0,0,0)',
      plot_bgcolor: 'rgba(0,0,0,0)',
      margin: { l: 0, r: 0, b: 0, t: 0 },
      scene: {
        xaxis: { visible: false },
        yaxis: { visible: false },
        zaxis: { visible: false },
        camera: {
          eye: { x: 1.8, y: 1.8, z: 1.8 }
        },
        bgcolor: 'rgba(0,0,0,0)'
      },
      showlegend: false,
      autosize: true
    };

    const config = {
      responsive: true,
      displayModeBar: false
    };

    Plotly.newPlot(containerRef.current, [edgeTrace, nodeTrace], layout, config);

    const handleResize = () => {
      if (containerRef.current) {
        Plotly.Plots.resize(containerRef.current);
      }
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [simulation]);

  return <div ref={containerRef} className="w-full h-full" />;
};
