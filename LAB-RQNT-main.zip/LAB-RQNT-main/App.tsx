
import React, { useState, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Simulator3D } from './components/Simulator3D';
import { DataTable } from './components/DataTable';
import { AnalysisPanel } from './components/AnalysisPanel';
import { generateSimulation } from './services/simulationEngine';
import { NodeValueType, SimulationState } from './types';
import { Activity, Beaker, Globe, ShieldCheck, Share2 } from 'lucide-react';

const App: React.FC = () => {
  const [numNodes, setNumNodes] = useState<number>(30);
  const [valueType, setValueType] = useState<NodeValueType>('Spin');
  const [simulation, setSimulation] = useState<SimulationState | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const handleRunSimulation = useCallback(() => {
    setIsSimulating(true);
    setTimeout(() => {
      const newState = generateSimulation(numNodes, valueType);
      setSimulation(newState);
      setIsSimulating(false);
    }, 600);
  }, [numNodes, valueType]);

  const handleExportJson = useCallback(() => {
    if (!simulation) return;
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(simulation, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `R-QNT_Export_${new Date().getTime()}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  }, [simulation]);

  const handleDownloadReport = useCallback(() => {
    if (!simulation) return;
    const stable = simulation.nodes.filter(n => n.isStable).length;
    const reportText = `
LABORATORIO R-QNT - REPORTE DE SIMULACIÓN
----------------------------------------
Investigador: Edward Pérez López
Fecha: ${new Date().toLocaleString()}
Tipo de Red: ${simulation.type}
Total Nodos: ${simulation.nodes.length}
Conexiones Relacionales: ${simulation.connections.length}
Nodos Coherentes: ${stable}
Nodos en Tensión: ${simulation.nodes.length - stable}
Relación de Coherencia: ${((stable / simulation.nodes.length) * 100).toFixed(2)}%
----------------------------------------
GENERADO POR EL SISTEMA DE ANÁLISIS SINTÉTICO R-QNT
    `.trim();
    
    const element = document.createElement("a");
    const file = new Blob([reportText], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = "R-QNT_Reporte.txt";
    document.body.appendChild(element);
    element.click();
    element.remove();
  }, [simulation]);

  const stableCount = simulation?.nodes.filter(n => n.isStable).length || 0;
  const unstableCount = (simulation?.nodes.length || 0) - stableCount;
  const connectionCount = simulation?.connections.length || 0;

  return (
    <div className="flex flex-col h-screen overflow-hidden font-sans bg-slate-950">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/50 backdrop-blur-md z-10">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-600 rounded-lg shadow-lg shadow-blue-500/20">
            <Globe className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white uppercase">
              Laboratorio <span className="text-blue-400">R-QNT</span>
            </h1>
            <p className="text-xs text-slate-400 font-mono">
              Investigador Principal: Edward Pérez López | v2.1.0
            </p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="hidden md:flex flex-col items-end">
            <span className="text-[10px] uppercase text-slate-500 font-bold tracking-widest">Sincronización</span>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${simulation ? 'bg-emerald-500 animate-pulse' : 'bg-slate-700'}`} />
              <span className="text-sm font-medium text-slate-300">
                {simulation ? 'Simulación Activa' : 'Fase de Calibración'}
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex flex-1 overflow-hidden">
        <Sidebar 
          numNodes={numNodes}
          setNumNodes={setNumNodes}
          valueType={valueType}
          setValueType={setValueType}
          onRun={handleRunSimulation}
          isSimulating={isSimulating}
          onExportJson={handleExportJson}
          onDownloadReport={handleDownloadReport}
          hasSimulation={!!simulation}
        />

        <div className="flex-1 flex flex-col overflow-hidden bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950">
          {!simulation ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
              <div className="relative mb-6">
                <div className="absolute inset-0 bg-blue-500/20 blur-3xl rounded-full" />
                <div className="relative w-24 h-24 rounded-3xl bg-slate-800/50 flex items-center justify-center border border-slate-700/50">
                  <Beaker className="w-12 h-12 text-slate-500" />
                </div>
              </div>
              <h2 className="text-2xl font-light text-slate-300 mb-2 tracking-tight">Preparado para el colapso de función</h2>
              <p className="max-w-md text-slate-500 text-sm leading-relaxed">
                Define los parámetros en el panel lateral y pulsa 'Iniciar Simulación' para observar la emergencia de la red cuántica relacional y sus topologías ocultas.
              </p>
            </div>
          ) : (
            <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
              <div className="flex-[2] flex flex-col p-4 gap-4 overflow-hidden">
                {/* Enhanced Stats row */}
                <div className="grid grid-cols-4 gap-4 h-24">
                  <div className="bg-slate-900/40 border border-slate-800 rounded-xl p-3 flex flex-col justify-center">
                    <span className="text-[9px] uppercase text-slate-500 font-bold tracking-widest mb-1">Densidad Nodal</span>
                    <span className="text-2xl font-mono font-bold text-white">{numNodes}</span>
                  </div>
                  <div className="bg-blue-950/20 border border-blue-900/30 rounded-xl p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <Share2 className="w-3 h-3 text-blue-400" />
                      <span className="text-[9px] uppercase text-blue-500/80 font-bold tracking-widest">Relaciones</span>
                    </div>
                    <span className="text-2xl font-mono font-bold text-blue-400">{connectionCount}</span>
                  </div>
                  <div className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      <span className="text-[9px] uppercase text-emerald-500/80 font-bold tracking-widest">Coherentes</span>
                    </div>
                    <span className="text-2xl font-mono font-bold text-emerald-400">{stableCount}</span>
                  </div>
                  <div className="bg-rose-950/20 border border-rose-900/30 rounded-xl p-3 flex flex-col justify-center">
                    <div className="flex items-center gap-2 mb-1">
                      <Activity className="w-3 h-3 text-rose-400" />
                      <span className="text-[9px] uppercase text-rose-500/80 font-bold tracking-widest">Inestables</span>
                    </div>
                    <span className="text-2xl font-mono font-bold text-rose-400">{unstableCount}</span>
                  </div>
                </div>

                {/* 3D Visualizer */}
                <div className="flex-1 bg-slate-900/20 border border-slate-800 rounded-2xl overflow-hidden relative group">
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/50 to-transparent pointer-events-none" />
                  <Simulator3D simulation={simulation} />
                  <div className="absolute top-4 left-4 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-700/50 text-[10px] text-slate-400 font-mono tracking-wider">
                    PROYECCIÓN TOPOLÓGICA CARTAN v3D
                  </div>
                </div>
              </div>

              {/* Right Panel: Analysis & Data */}
              <div className="flex-1 border-l border-slate-800 flex flex-col min-w-[380px] bg-slate-950/50 backdrop-blur-xl">
                <AnalysisPanel simulation={simulation} />
                <div className="h-[300px] border-t border-slate-800 flex flex-col overflow-hidden">
                   <div className="p-4 bg-slate-900/40 border-b border-slate-800 flex items-center justify-between">
                      <h3 className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Validador de Registros</h3>
                      <div className="text-[9px] font-mono text-slate-600 uppercase">Tiempo Real</div>
                   </div>
                   <DataTable simulation={simulation} />
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
